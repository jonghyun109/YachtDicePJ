﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtDice
{
    class GameManager
    {
        private int currentRound;
        private int maxRounds;
        private int rollsPerRound;
        private ScoreBoard scoreBoard;

        public GameManager(int totalRounds = 12, int maxRolls = 3)
        {
            currentRound = 1;
            maxRounds = totalRounds;
            rollsPerRound = maxRolls;
            scoreBoard = new ScoreBoard();
        }

        public void StartGame(Player player, Dice dice)
        {
            while (currentRound <= maxRounds)
            {
                Console.WriteLine($"Round {currentRound}/{maxRounds}");
                int rollCount = 0;

                while (rollCount < rollsPerRound)
                {
                    dice.RollingDice();
                    Console.WriteLine($"Roll {rollCount + 1}/{rollsPerRound}");
                    player.UpdateDiceState(dice.StopDice(), dice.isDiceRoll);

                    // 플레이어가 선택하거나 종료할 때까지 대기
                    Console.WriteLine("Enter 'lock' to lock dice, or 'stop' to finalize this round.");
                    string input = Console.ReadLine()?.ToLower();
                    if (input == "stop")
                    {
                        break;
                    }
                    else if (input == "lock")
                    {
                        Console.WriteLine("Select dice to lock/unlock (0-4):");
                        if (int.TryParse(Console.ReadLine(), out int index))
                        {
                            dice.ChooseDice(index);
                        }
                    }

                    rollCount++;
                }

                // 점수판에 현재 주사위 값 업데이트
                UpdateScoreBoard(player);
                currentRound++;
            }

            Console.WriteLine("Game Over! Final Scores:");
            scoreBoard.DisplayScores();
        }

        private void UpdateScoreBoard(Player player)
        {
            int[] diceNum = player.CurrentDice;
            scoreBoard.CompareDices(diceNum);
            player.SaveDiceToHistory();
        }
    }
}
