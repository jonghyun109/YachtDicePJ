﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtDice
{
    class Player
    {
        public int[] CurrentDice { get; private set; }

        public Player()
        {
            CurrentDice = new int[5];
        }

        public void UpdateDice(int[] diceValues)
        {
            if (diceValues.Length == CurrentDice.Length)
            {
                Array.Copy(diceValues, CurrentDice, diceValues.Length);
            }
        }
    }
}
