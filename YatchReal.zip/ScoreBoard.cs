﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace YachtDice
{
    
    enum Scores
    {
        Aces,
        Deuces,
        Threes,
        Fours,
        Fives,
        Sixes,
        Choice,
        FourOfaKind,
        FullHouse,
        SStraight,
        LStraight,
        Yacht,        
    }

    class ScoreBoard
    {
        private string[] scoreNames;
        private int[] scoreValues;

        public ScoreBoard()
        {
            scoreNames = Enum.GetNames(typeof(Scores));
            scoreValues = new int[scoreNames.Length];
        }

        public void DisplayScores()
        {
            Console.WriteLine("====== 점수판 ======");
            for (int i = 0; i < scoreNames.Length; i++)
            {
                Console.WriteLine($"{scoreNames[i]}: {scoreValues[i]}");
            }
            Console.WriteLine("====================");
        }       

        public void CompareDices(int[] dices)
        {

            // 숫자들의 합 계산
            int[] numsSum = new int[6];
            foreach (int dice in dices)
            {
                numsSum[dice - 1] += dice;
            }

            // 전체 합계 계산
            int totalSum = dices.Sum();

            // Four of a Kind 계산
            bool isFourOfKind = false;
            int fourOfKindNum = 0;
            int[] counts = new int[6];

            foreach (int dice in dices)
            {
                counts[dice - 1]++;
            }

            for (int i = 0; i < counts.Length; i++)
            {
                if (counts[i] == 4 || counts[i] == 5)
                {
                    isFourOfKind = true;
                    fourOfKindNum += (i + 1) * 4; // 주사위 값 계산
                }
            }

            // Full House 계산
            int[] countsFH = new int[6];
            bool isFullHouse = false;

            foreach (int dice in dices)
            {
                countsFH[dice - 1]++;
            }

            bool hasThree = countsFH.Contains(3);
            bool hasTwo = countsFH.Contains(2);
            isFullHouse = hasThree && hasTwo;

            // Small Straight 계산
            int countSmallStraight = 1;
            bool isSmallStraight = false;

            int[] dicesClones = (int[])dices.Clone();
            Array.Sort(dicesClones);

            for (int i = 1; i < dicesClones.Length; i++)
            {
                if (dicesClones[i] == dicesClones[i - 1] + 1)
                {
                    countSmallStraight++;
                    if (countSmallStraight >= 4)
                    {
                        isSmallStraight = true;
                        break;
                    }
                }
                else
                {
                    countSmallStraight = 1;
                }
            }

            // Large Straight 계산
            int countLargeStraight = 1;
            bool isLargeStraight = false;

            for (int i = 1; i < dicesClones.Length; i++)
            {
                if (dicesClones[i] == dicesClones[i - 1] + 1)
                {
                    countLargeStraight++;
                    if (countLargeStraight == 5)
                    {
                        isLargeStraight = true;
                        break;
                    }
                }
                else
                {
                    countLargeStraight = 1;
                }
            }

            // Yacht 계산
            int[] countFive = new int[6];
            bool isYacht = false;
           
            foreach (int dice in dices)
            {
                countFive[dice - 1]++;
            }
            
            for (int i = 0; i < countFive.Length; i++)
            {
                if (countFive[i] == 5)
                {
                    isYacht = true;
                }
            }
            int yachtScore = isYacht ? 50 : 0;
        }
    }
}