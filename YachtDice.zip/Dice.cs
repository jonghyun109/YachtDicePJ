﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace YachtDice
{
    class Dice
    {
        ConsoleKeyInfo keyInput = new ConsoleKeyInfo();        
        int[] dices = new int[6] {1,2,3,4,5,6};
        bool[] isdiceRoll = new bool[6];
        Random random = new Random();
         
        public void RollDice()
        { 
            for (int i = 0; i < 5; i++)
            {
                if (isdiceRoll[i] == false)
                {
                    int temp = dices[i];
                }
                dices[i] = random.Next(1, 7);
                isdiceRoll[i] = true;

                Console.Write(dices[i] + "　");                
            }
        }



        public void RollingDice(Action action)
        {    
            
            while (true)
            {
                for (int i = 0; i < 5; i++)
                {
                    dices[i] = random.Next(1, 7);
                    Console.Write(dices[i] + "　");
                }                
                Thread.Sleep(30);
                action();
                Console.Clear();                
                
            }
        }
        public void stopDice()
        {
            if (keyInput == Console.ReadKey())
            {
                RollDice();
            }
        }
    }
}
