﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtDice
{
    enum SetScoreBoard
    {
        Ones,
        Twos,
        Threes,
        Fours,
        Fives,
        Sixes,
        Choice,
        FourOfaKind,
        FullHouse,
        SStraight,
        LStraight,
        Yacht
    }
    
    class ScoreBoard
    {
        int currentPos = 0;        
        public void InGameDisplayBoard()
        {
            string[] scoreName = Enum.GetNames(typeof(SetScoreBoard));
            //int[] score = new int[Enum.GetValues(typeof(SetScoreBoard))];            
            int leftCursor = 60;
            int topCursor = 0;
            ConsoleKeyInfo inputKey = new ConsoleKeyInfo();

            foreach (string board in scoreName)
            {
                Console.SetCursorPosition(leftCursor, topCursor);
                Console.WriteLine(board);
                topCursor++;
            }
            topCursor = 0;
            while (true)
            {                
                Console.SetCursorPosition(leftCursor, topCursor);
                //for (int i = 0; i < score.Length; i++)
                //{
                //    if (topCursor == score[i])
                //    {
                //        Console.BackgroundColor = ConsoleColor.Gray;
                //    }                    
                //    Console.ResetColor();
                //}
                inputKey = Console.ReadKey();
                if (inputKey.Key == ConsoleKey.Enter) break;
                else if (inputKey.Key == ConsoleKey.UpArrow)
                {
                    topCursor = (topCursor +11)%12;
                    Console.SetCursorPosition(leftCursor, topCursor);
                    
                }
                else if (inputKey.Key == ConsoleKey.DownArrow)
                { 
                    topCursor = (topCursor + 1)%12;
                    Console.SetCursorPosition(leftCursor, topCursor);
                }
            }
            //switch

            //int currentSelet = 0;

            //while (true)
            //{
            //    Console.Clear();
            //    Console.WriteLine("주사위를 선택하세요 \n이동 : ← →  \n선택/해제 : SpaceBar  \n완료 후 다시 굴리기 : Enter ");

            //    for (int i = 0; i < 11; i++)
            //    {
            //        if (i == currentSelet)
            //        {
            //            Console.BackgroundColor = ConsoleColor.Gray;
            //        }
            //        //if (Enum.GetValues(typeof(SetScoreBoard)))
            //        //{
            //        //    Console.ForegroundColor = ConsoleColor.White;
            //        //}
            //        //else
            //        //{
            //        //    Console.ForegroundColor = ConsoleColor.Red;
            //        //}                    
            //        Console.ResetColor();
            //    }

            //    var input = Console.ReadKey(true);
            //    if (input.Key == ConsoleKey.Enter) break;
            //    else if (input.Key == ConsoleKey.UpArrow) currentSelet = (currentSelet + 10) % 11;//바로 왼쪽가면 값 4로 맨오른쪽
            //    else if (input.Key == ConsoleKey.DownArrow) currentSelet = (currentSelet + 1) % 11;//

            //}
        }
    }



}
